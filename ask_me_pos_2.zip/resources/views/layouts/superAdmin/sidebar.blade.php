<?php
$baseURL = getBaseURL();
?>

<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <ul class="sidebar-menu">
            <li class="header">Main Navigation</li>
        </ul>
        <div id="left_menu_to_scroll">
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu" data-widget="tree">
                <li>
                    <a href="{{route('superAdmin.dashboard')}}">
                        <i data-feather="home"></i> <span>Dashboard</span></a>
                </li>
                <li>
                    <a href="{{route('superAdmin.settings')}}">
                        <i data-feather="settings"></i> <span>Settings</span></a>
                </li>
                <li>
                    <a href="{{route('superAdmin.restaurantList')}}">
                        <i data-feather="grid"></i> <span>Restaurant List</span></a>
                </li>
            </ul>
        </div>
    </section>
    <!-- /.sidebar -->
</aside>
