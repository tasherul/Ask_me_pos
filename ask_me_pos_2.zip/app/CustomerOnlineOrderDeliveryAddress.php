<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerOnlineOrderDeliveryAddress extends Model
{
    protected $table = 'tbl_customer_online_order_delivery_addresses';
}
