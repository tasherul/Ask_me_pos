<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RestaurantCategoryForSupplier extends Model
{
    protected $table = 'tbl_restaurant_category_for_suppliers';

}
