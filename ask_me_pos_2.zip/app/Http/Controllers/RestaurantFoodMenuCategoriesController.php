<?php

namespace App\Http\Controllers;

use App\RestaurantFoodMenuCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class RestaurantFoodMenuCategoriesController extends Controller
{
    public function __construct()
    {
        $this->middleware('restaurantUser');
        auth()->setDefaultDriver('restaurantUser');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = RestaurantFoodMenuCategory::where('restaurant_id', Auth::guard('restaurantUser')->user()->restaurant_id)
                                                    ->where('del_status', 'Live')
                                                    ->orderBy('delay_time', 'asc')
                                                    ->orderBy('updated_at', 'desc')
                                                    ->get();
        return view('pages.restaurant.sale.foodMenuCategory.index', compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages.restaurant.sale.foodMenuCategory.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
//        return $request->all();
        $rules = array(
            'name' => 'required',
            'delay_time' => 'required|numeric'
        );

        $validator = Validator::make(\request()->all(), $rules);

        // process the creation
        if ($validator->fails()) {
            return redirect()->route('food-menu-categories.create')
                ->withErrors($validator)
                ->withInput(\request()->all());
        } else {
            // store
            $category = new RestaurantFoodMenuCategory();
            $category->name = $request->name;
            $category->delay_time = $request->delay_time;
            $category->description = $request->description;
            $category->restaurant_id = Auth::guard('restaurantUser')->user()->restaurant_id;
            $category->user_id = Auth::guard('restaurantUser')->id();
            $category->save();

            toastr()->success('Added successfully.');
            // redirect
            return redirect()->route('food-menu-categories.index');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (Auth::guard('restaurantUser')->id() == RestaurantFoodMenuCategory::find($id)->user_id) {
            $category = RestaurantFoodMenuCategory::find($id);

            return view('pages.restaurant.sale.foodMenuCategory.edit', compact('category'));
        } else {
            toastr()->error('You are not allowed to show this resource because this is not belongs to you.');
            // redirect
            return redirect()->route('food-menu-categories.index');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (Auth::guard('restaurantUser')->id() == RestaurantFoodMenuCategory::find($id)->user_id) {
            $rules = array(
                'name' => 'required',
                'delay_time' => 'required|numeric'
            );

            $validator = Validator::make(\request()->all(), $rules);

            // process the creation
            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput(\request()->all());
            } else {
                // store
                $category = RestaurantFoodMenuCategory::find($id);
                $category->name = $request->name;
                $category->delay_time = $request->delay_time;
                $category->description = $request->description;
                $category->restaurant_id = Auth::guard('restaurantUser')->user()->restaurant_id;
                $category->user_id = Auth::guard('restaurantUser')->id();
                $category->save();

                toastr()->success('Updated successfully.');
                // redirect
                return redirect()->route('food-menu-categories.index');
            }
        } else {
            toastr()->error('You are not allowed to update this resource because this is not belongs to you.');
            // redirect
            return redirect()->route('food-menu-categories.index');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        if (Auth::guard('restaurantUser')->id() == RestaurantFoodMenuCategory::find($id)->user_id) {
            $category = RestaurantFoodMenuCategory::find($id);
            if ($category) {
                $category = RestaurantFoodMenuCategory::find($id);
                $category->del_status = "Deleted";
                $category->save();

                toastr()->success('Deleted successfully.');
                // redirect
                return redirect()->route('food-menu-categories.index');
            } else {
                toastr()->error('Unable to delete.');
                // redirect
                return redirect()->route('food-menu-categories.index');
            }
        } else {
            toastr()->error('You are not allowed to delete this resource because this is not belongs to you.');
            // redirect
            return redirect()->route('food-menu-categories.index');
        }
    }
}
