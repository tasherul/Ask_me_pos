<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RestaurantSettingsTaxField extends Model
{
    protected $table = 'tbl_restaurant_settings_tax_fields';
}
