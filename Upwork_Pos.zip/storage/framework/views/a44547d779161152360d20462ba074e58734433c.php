<!doctype html>
<html lang="en">

<?php
$baseURL = getBaseURL()
?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

<?php if(Request::path() === "SuperAdmin/SALogin" || Request::path() === "restaurant/sign-up" || Request::path() === "restaurant/login"): ?>
    <!-- jQuery 3 -->
        <script src="<?php echo $baseURL.'assets/bower_components/jquery/dist/jquery.min.js'; ?>"></script>
        <!-- Select2 -->
        <script src="<?php echo $baseURL.'assets/bower_components/select2/dist/js/select2.full.min.js'; ?>"></script>
        <!-- Select2 -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/select2/dist/css/select2.min.css'; ?>">
        <!-- Bootstrap 3.3.7 -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/bootstrap/dist/css/bootstrap.min.css'; ?>">
        <!-- Font Awesome -->
        <link rel="stylesheet"
              href="<?php echo $baseURL.'assets/bower_components/font-awesome/css/font-awesome.min.css'; ?>">
        <!-- Ionicons -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/Ionicons/css/ionicons.min.css'; ?>">
        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/dist/css/AdminLTE.min.css'; ?>">
        <!-- iCheck -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/plugins/iCheck/square/blue.css'; ?>">
        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo $baseURL.'assets/images/favicon.ico'; ?>" type="image/x-icon">
        <!-- Favicon -->
        <link rel="icon" href="<?php echo $baseURL.'assets/images/favicon.ico'; ?>>" type="image/x-icon">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Google Font -->
        <link rel="stylesheet"
              href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<?php else: ?>
    <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/dist/css/AdminLTE.css'; ?>">
        <!-- jQuery 3 -->
        <script src="<?php echo $baseURL.'assets/bower_components/jquery/dist/jquery.min.js'; ?>"></script>
        <!-- Select2 -->
        <script src="<?php echo $baseURL.'assets/bower_components/select2/dist/js/select2.full.min.js'; ?>"></script>
        <!-- Select2 -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/select2/dist/css/select2.min.css'; ?>">
        <!-- InputMask -->
        <script src="<?php echo $baseURL.'assets/plugins/input-mask/jquery.inputmask.js'; ?>"></script>
        <script src="<?php echo $baseURL.'assets/plugins/input-mask/jquery.inputmask.date.extensions.js'; ?>"></script>
        <script src="<?php echo $baseURL.'assets/plugins/input-mask/jquery.inputmask.extensions.js'; ?>"></script>
        <!-- iCheck -->
        <script src="<?php echo $baseURL.'assets/plugins/iCheck/icheck.min.js'; ?>"></script>
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/plugins/iCheck/all.css'; ?>">

        <!-- remove from below condition || Route::is('purchases.*') -->

    <?php if(Request::path() === "restaurant/purchase/purchases/create" || Request::is('restaurant/*/*/*/edit') || Request::path() === "restaurant/sale/food-menu-modifiers/create" || Request::path() === "restaurant/sale/food-menu/create" || Request::path() === "restaurant/waste/wastes/create" || Request::path() === "restaurant/stock-adjustment/create" || Request::is('restaurant/*/*/edit')): ?>
            
            <!-- Sweet alert -->
            <script src="<?php echo $baseURL.'assets/bower_components/sweetalert2/dist/sweetalert.min.js'; ?>"></script>
            <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/sweetalert2/dist/sweetalert.min.css'; ?>">
    <?php else: ?>
        <!-- Sweet alert 2-->
            <script src="<?php echo $baseURL.'resources/assets/js/sweetalert2.js'; ?>"></script>
            <link rel="stylesheet" href="<?php echo $baseURL.'assets/POS/sweetalert2/dist/sweetalert.min.css'; ?>">
    <?php endif; ?>

    <!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
    

    <!-- Numpad -->
        <script src="<?php echo $baseURL.'assets/bower_components/numpad/jquery.numpad.js'; ?>"></script>
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/numpad/jquery.numpad.css'; ?>">
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/numpad/theme.css'; ?>">
        <!--datepicker-->
        <!-- bootstrap datepicker -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/datepicker/datepicker.css'; ?>">

        <!-- bootstrap datepicker -->
        <script src="<?php echo $baseURL.'assets/bower_components/datepicker/bootstrap-datepicker.js'; ?>"></script>

        <!-- Bootstrap 3.3.7 -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/bootstrap/dist/css/bootstrap.min.css'; ?>">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/font-awesome/css/font-awesome.min.css'; ?>">
        <!-- Ionicons -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/bower_components/Ionicons/css/ionicons.min.css'; ?>">

        <link rel="stylesheet" href="<?php echo $baseURL.'assets/dist/css/jquery.mCustomScrollbar.css'; ?>">
        <!-- AdminLTE Skins. Choose a skin from the css/skins
             folder instead of downloading all of them to reduce the load. -->
        <link rel="stylesheet" href="<?php echo $baseURL.'assets/dist/css/skins/_all-skins.css'; ?>">
        <!-- iCheck -->
        <link href="<?php echo $baseURL.'asset/plugins/iCheck/minimal/color-scheme.css'; ?>" rel="stylesheet">
        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo $baseURL.'assets/images/favicon.ico'; ?>" type="image/x-icon">
        <!-- Favicon -->
        <link rel="icon" href="<?php echo $baseURL.'assets/images/favicon.ico'; ?>" type="image/x-icon">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Google Font -->
        <link rel="stylesheet"
              href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
        <script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>
    <?php endif; ?>

    <link rel="stylesheet" href="<?php echo $baseURL.'resources/assets/css/custom/global-style.css'; ?>">

    <?php echo $__env->yieldContent('style'); ?>

    <title><?php echo e(config('APP_NAME', 'Ask Me POS')); ?></title>

    <?php echo toastr_css(); ?>
</head>
<body class="<?php if( Request::path() === 'SuperAdmin/SALogin' || Request::path() === 'restaurant/sign-up' || Request::path() === 'restaurant/login'): ?> loginPage <?php else: ?> hold-transition skin-blue sidebar-mini sidebar-collapse <?php endif; ?>">

<?php if(Request::path() === "SuperAdmin/SALogin" || Request::path() === "restaurant/sign-up" || Request::path() === "restaurant/login"): ?>
    <?php echo $__env->yieldContent('content'); ?>
<?php else: ?>
    <?php if(Auth::guest()): ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php else: ?>
        <div class="wrapper">
            <?php if(Auth::guard('superAdmin')->user()): ?>
                <?php echo $__env->make('layouts.superAdmin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('layouts.superAdmin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('layouts.restaurant.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('layouts.restaurant.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            
            <?php echo $__env->yieldContent('content'); ?>

            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $baseURL.'assets/bower_components/bootstrap/dist/js/bootstrap.min.js'; ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo $baseURL.'assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js'; ?>"></script>
<!-- FastClick -->
<script src="<?php echo $baseURL.'assets/bower_components/fastclick/lib/fastclick.js'; ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo $baseURL.'assets/dist/js/adminlte.min.js'; ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo $baseURL.'assets/dist/js/demo.js'; ?>"></script>
<script type="text/javascript" src="<?php echo $baseURL.'assets/POS/js/jquery.cookie.js'; ?>"></script>
<!-- custom scrollbar plugin -->
<script src="<?php echo $baseURL.'assets/dist/js/jquery.mCustomScrollbar.concat.min.js'; ?>"></script>
<!-- material icon -->
<script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

<script src="<?php echo $baseURL.'resources/assets/js/custom/app.js'; ?>"></script>

<?php echo $__env->yieldContent('script'); ?>
</body>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
</html>
<?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/layouts/app.blade.php ENDPATH**/ ?>