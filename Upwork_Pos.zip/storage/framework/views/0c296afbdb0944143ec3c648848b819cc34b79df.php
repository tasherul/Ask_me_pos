

<?php
$baseURL = getBaseURL()
?>
<?php $__env->startSection('title'); ?>
    <title>Ask Me Pos | Find A Restaurant </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="parallax-mirror" style="visibility: visible; z-index: -100; position: fixed; top: -10px; left: 0px; overflow: hidden; transform: translate3d(0px, 0px, 0px); height: 590px; width: 100%;">
        <img class="parallax-slider" src="<?php echo $baseURL.'assets/images/b-2.jpg'; ?>" style="transform: translate3d(0px, 0px, 0px); position: absolute; top: 8px; left: 0px; height: 548px; width: 100%; max-width: none;">
    </div>

    <div id="parallax-wrap" class="parallax-container parallax-home parallax-search" data-parallax="scroll" data-position="top" data-bleed="10" data-image-src="<?php echo $baseURL.'assets/images/index_background.png'; ?>">
        <div class="search-wraps advance-search" style="padding-top:50px;"> 
            <h1 class="home-search-text">Login & Signup</h1> 
            <p class="home-search-subtext">sign up to start ordering</p> 

        </div> <!--search-wrapper-->
    </div>
    <!--section--->
    <div class="sections section-grey2 section-checkout" style="transform: none;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="box-grey rounded"> 
                        <div class="section-label bottom20"> 
                            <a class="section-label-a"> 
                                
                                <i class="fa fa-user i-big"></i>
                                <span class="bold" style="background:#fff;"> Log in to your account</span> <b></b> 
                            </a> 
                        </div> 
                        <form id="forms" class="forms" method="POST" action="<?php echo e(route('customer.doLogin')); ?>">
                            <?php echo csrf_field(); ?>                            
                            <div class="row top10"> 
                                <div class="col-md-12 "> 
                                    <input class="grey-fields" placeholder="Mobile number or email" required="required" type="text" value="" name="email_phone" id="email_phone"> 
                                </div> 
                            </div> 
                            <!--row--> 
                            <div class="row top10"> 
                                <div class="col-md-12 "> 
                                    <input class="grey-fields" placeholder="Password" required="required" type="password" value="" name="password" id="password"> 
                                </div> 
                            </div> 
                            <!--row--> 
                            <div class="row top15"> 
                                <div class="col-md-6"> 
                                    <a href="javascript:;" class="forgot-pass-link2 block orange-text text-center"> Forgot Password <i class="ion-help"></i> 
                                    </a> 
                                </div> 
                                <div class="col-md-6"> 
                                    <input type="submit" value="Login" class="theme-button medium full-width"> 
                                </div> 
                            </div> 
                        </form> 
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="box-grey rounded top-line-theme"> 
                        <form id="form-signup" class="form-signup" method="POST" action="<?php echo e(route('customer.doSignUp')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="section-label bottom20"> 
                                <a class="section-label-a"> 
                                    
                                    <i class="fa fa-edit i-big theme-color"></i>
                                    <span class="bold" style="background:#fff;"> Sign up</span> 
                                    <b></b> 
                                </a> 
                            </div>
                            <div class="row top10"> 
                                <div class="col-md-12"> 
                                    <input class="grey-fields" placeholder="Name" required="required" type="text" value="<?php echo e(old('name')); ?>" name="name" id="name"> 
                                    <?php if($errors->has('name')): ?>
                                        <div class="alert alert-danger" style="padding: 5px !important; margin:5px 0px 0px 0px !important;">
                                            <p>
                                            <p><?php echo e($errors->first('name')); ?></p></p>
                                        </div>
                                    <?php endif; ?>
                                </div> 
                            </div>
                            <div class="row top10"> 
                                <div class="col-md-6"> 
                                    <input class="grey-fields" placeholder="Phone" required="required" type="text" value="<?php echo e(old('phone')); ?>" name="phone" id="phone"> 
                                    <?php if($errors->has('phone')): ?>
                                        <div class="alert alert-danger" style="padding: 5px !important; margin:5px 0px 0px 0px !important;">
                                            <p>
                                            <p><?php echo e($errors->first('phone')); ?></p></p>
                                        </div>
                                    <?php endif; ?>
                                </div> 
                                <div class="col-md-6"> 
                                    <input class="grey-fields" placeholder="Email Address" required="required" type="email" value="<?php echo e(old('email')); ?>" name="email" id="email">
                                    <?php if($errors->has('email')): ?>
                                        <div class="alert alert-danger" style="padding: 5px !important; margin:5px 0px 0px 0px !important;">
                                            <p>
                                            <p><?php echo e($errors->first('email')); ?></p></p>
                                        </div>
                                    <?php endif; ?> 
                                </div>
                            </div>
                            <div class="row top10"> 
                                <div class="col-md-12"> 
                                    <input class="grey-fields" placeholder="Password" required="required" type="text" value="" name="password" id="password">
                                    <?php if($errors->has('password')): ?>
                                        <div class="alert alert-danger" style="padding: 5px !important; margin:5px 0px 0px 0px !important;">
                                            <p>
                                            <p><?php echo e($errors->first('password')); ?></p></p>
                                        </div>
                                    <?php endif; ?> 
                                </div> 
                            </div>
                            <div class="row top10"> 
                                <div class="col-md-12"> 
                                    <input class="grey-fields" placeholder="Confirm Password" required="required" type="text" value="" name="password_confirmation" id="password_confirmation"> 
                                    <?php if($errors->has('password_confirmation')): ?>
                                        <div class="alert alert-danger" style="padding: 5px !important; margin:5px 0px 0px 0px !important;">
                                            <p>
                                            <p><?php echo e($errors->first('password_confirmation')); ?></p></p>
                                        </div>
                                    <?php endif; ?>
                                </div> 
                            </div>
                            
                            <div class="row top10"> 
                                <div class="col-md-12 "> 
                                    <input type="submit" value="Create Account" class="theme-button medium block full-width"> 
                                </div> 
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo $baseURL.'resources/assets/js/custom/serviceWorker.js'; ?>"></script>
    
    <script src="<?php echo $baseURL.'assets/plugins/input-mask/jquery.inputmask.js'; ?>"></script>
    <script>
        $('#phone').inputmask("+19999999999");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/pages/customer/signup.blade.php ENDPATH**/ ?>