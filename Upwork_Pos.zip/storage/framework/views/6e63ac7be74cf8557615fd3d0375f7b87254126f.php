

<?php
$baseURL = getBaseURL()
?>
<?php $__env->startSection('title'); ?>
    <title>Ask Me Pos | Find A Restaurant </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="parallax-mirror" style="visibility: visible; z-index: -100; position: fixed; top: -10px; left: 0px; overflow: hidden; transform: translate3d(0px, 0px, 0px); height: 590px; width: 100%;">
        <img class="parallax-slider" src="<?php echo $baseURL.'assets/images/index_background.png'; ?>" style="transform: translate3d(0px, 0px, 0px); position: absolute; top: 8px; left: 0px; height: 548px; width: 100%; max-width: none;">
    </div>

    <div id="parallax-wrap" class="parallax-container parallax-home" data-parallax="scroll" data-position="top" data-bleed="10" data-image-src="<?php echo $baseURL.'assets/images/index_background.png'; ?>">
        <div class="search-wraps advance-search"> 
            <h1 class="home-search-text">Find restaurant by name</h1> 
            <p class="home-search-subtext">Order Delivery Food Online From Local Restaurants</p> 

            <form method="GET" id="forms-search" action="#" style="padding-bottom: 40px;"> 
                <div class="search-input-wraps rounded30"> 
                    <div class="row"> 
                        <div class="col-sm-10 col-xs-10"> 
                            <div class="easy-autocomplete relative">
                                <input placeholder="Restaurant name" required="required"  class="form__input" type="text" value="" name="restaurant-name" id="restaurant-name" autocomplete="off">
                                <div class="easy-autocomplete-container" id="eac-container-restaurant-name">
                                    <ul></ul>
                                </div>
                            </div> 
                        </div> 
                        <div class="col-sm-2 col-xs-2 relative"> 
                            <button type="submit"><i class="fa fa-search"></i></button> 
                        </div> 
                    </div> 
                </div> <!--search-input-wrap--> 
            </form> 
        </div> <!--search-wrapper-->
    </div>
    <!--HOW IT WORKS SECTIONS-->
    <div class="sections section-how-it-works">
        <div class="container"> 
            <h2 class="center">How it works's</h2> 
            <p class="center">Get your favourite food in 4 simple steps</p> 
            <div class="row"> 
                <div class="col-md-3 col-sm-3 center"> 
                    <div class="steps step1-icon"> 
                        <img src="<?php echo $baseURL.'assets/images/step1.png'; ?>"> 
                    </div> <h3>Search</h3> 
                    <p>Find all restaurants available near you</p> 
                </div> 
                <div class="col-md-3 col-sm-3 center"> 
                    <div class="steps step2-icon"> 
                        <img src="<?php echo $baseURL.'assets/images/step2.png'; ?>"> 
                    </div> 
                    <h3>Choose</h3> 
                    <p>Browse hundreds of menus to find the food you like</p> 
                </div> 
                <div class="col-md-3 col-sm-3 center"> 
                    <div class="steps step2-icon"> 
                        <img src="<?php echo $baseURL.'assets/images/step3.png'; ?>"> 
                    </div> 
                    <h3>Pay</h3> 
                    <p>It's quick, secure and easy</p> 
                </div> 
                <div class="col-md-3 col-sm-3 center"> 
                    <div class="steps step2-icon"> 
                        <img src="<?php echo $baseURL.'assets/images/step4.png'; ?>"> 
                    </div> 
                    <h3>Enjoy</h3> 
                    <p>Food is prepared &amp; delivered to your door</p> 
                </div> 
            </div> 
        </div> <!--container-->
    </div>
    <!--END HOW IT WORKS SECTIONS-->

    <!--FEATURED RESTAURANT SECIONS-->
    <div class="sections section-feature-resto">
        <div class="container"> 
            <h2>Featured Restaurants</h2> 
            <div class="row" id="featured_restaurant"> 

                
            </div>
            
        </div><!--Container-->
    </div>
    <!--END FEATURED RESTAURANT SECIONS-->

    <!--CUISINE SECTIONS-->
    <div class="sections section-cuisine" style="background: #ededed;">
        <div class="container nopad">
            <div class="row">
                <div class="col-md-3 nopad">
                    <img src="<?php echo $baseURL.'assets/images/cuisine.png'; ?>" class="img-cuisine">
                </div>
                <div class="col-md-9 nopad"> 
                    <h2>Browse by cuisine</h2> 
                    <p class="sub-text center">choose from your favorite cuisine</p> 
                    <div class="row"> 
                        <?php $__currentLoopData = $cuisines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuisine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 col-sm-4 indent-5percent nopad"> 
                                <a href="<?php echo e(route('restaurantByCuisine')); ?>?cuisine=<?php echo e($cuisine->id); ?>" class="even"> <?php echo e($cuisine->name); ?><span>(<?php echo e(count($cuisine->restaurants)); ?>)</span> </a> 

                            </div> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                    </div> 
                </div> 
            </div>
        </div> <!--container-->
    </div>
    <!--END CUISINE SECTIONS-->

    <!--Delivery option Modal -->
    <div class="modal fade" id="deliveryOptionModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="deliveryOptionLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            
            <div class="modal-body p-4">
                <div class="row">
                    <div class="col text-center">
                        <h5 class="modal-title" id="deliveryOptionLabel">Select Which One Do You Want?</h5>
                    </div>
                    <div class="col text-center">
                        <a href="" class="btn theme-button delivery-option" data-delivery_option="delivery">DELIVERY</a>
                        <a href="" class="btn theme-button delivery-option" data-delivery_option="pickup">PICK UP</a>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo $baseURL.'resources/assets/js/custom/serviceWorker.js'; ?>"></script>
    <script src="<?php echo $baseURL.'resources/assets/js/custom/customer/featuredRestaurant.js'; ?>"></script>
    <script>
        $(document).ready(function () {
            "use strict";

            var check_delivery_option = <?php echo e($delivery_option); ?>;
            
            // if (check_delivery_option == true) {
            //     $('#deliveryOptionModal').modal('hide');

            // } else {
            //     $('#deliveryOptionModal').modal('toggle');

            // }


            // $('.delivery-option').click(function (e) { 
            //     e.preventDefault();
            //     var delivery_option = $(this).data('delivery_option');
            //     //alert(delivery_option);
            //     var baseURL = getBaseURL();

            //     $.ajax({
            //         type: "post",
            //         url: baseURL+'/set-delivery-option-by-ajax',
            //         headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            //         data: {
            //             delivery_option : delivery_option
            //         },
            //         dataType: "json",
            //         success: function (response) {
            //             //console.log(response);
            //             if (response.success) {
            //                 $('#deliveryOptionModal').modal('hide');
            //                 // alert(response.success);
            //             }
            //         }
            //     });
            // });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\ask_me_pos_2\resources\views/pages/index.blade.php ENDPATH**/ ?>