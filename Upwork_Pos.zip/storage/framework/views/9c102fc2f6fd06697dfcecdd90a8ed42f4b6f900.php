<?php
$baseURL = getBaseURL()
?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Purchase Details
            </h1>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-2 form-group">
                    <h1>Refernce No</h1>

                    <p><?php echo e($res_purchese->reference_no); ?></p>
                </div>
                <div class="col-md-2 form-group">
                    <h1>Supplier</h1>
                    <p><?php echo e($res_purchese->supplier_id); ?></p>
                </div>
                <div class="col-md-2 form-group">
                    <h1>Date</h1>
                    <p><?php echo e($res_purchese->date); ?></p>
                </div>
                <div class="col-md-2 form-group">
                    <h1>Total</h1>
                    <p><?php echo e($res_purchese->grand_total); ?></p>
                </div>
                <div class="col-md-2 form-group">
                    <h1>Paid</h1>
                    <p><?php echo e($res_purchese->paid); ?></p>
                </div>
                <div class="col-md-2 form-group">
                    <h1>Due</h1>
                    <p><?php echo e($res_purchese->due); ?></p>
                </div>
            </div>
                <div class="row">
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="box box-primary">
                            <!-- /.box-header -->
                            <div class="box-body table-responsive">
                                <div class="row">
                                    <div class="col-md-2 form-group">
                                    </div>
                                    <div class="hidden-lg">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>

                                </div>
                                <table id="datatable" class="table table-striped">
                                    <thead>
                                    <tr>
                                        
                                        
                                        <th class="title text-center">Ingredient Id</th>
                                        <th class="title text-center">Name</th>
                                        <th class="title text-center">Purchase price</th>
                                        <th class="title text-center">Alert Quantity</th>
                                        <th class="title text-center">Unit Price</th>
                                        <th class="title text-center">-</th>
                                        <th class="title text-center">-</th>
                                        <th class="title text-center">-</th>
                                    </tr>
                                    </thead>
                                    <tbody class="purchase_body">
                                        <?php $__currentLoopData = $all_res_purchese; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_ngredients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="purchase_row">
                                                        
                                                        <td class="text-center"><?php echo e($v_ngredients->id); ?></td>
                                                        <td class="text-center"><?php echo e($v_ngredients->food_name); ?></td>
                                                        <td class="text-center"><?php echo e($v_ngredients->unit_price); ?></td>
                                                        <td class="text-center"><?php echo e($v_ngredients->quantity_amount); ?></td>
                                                        <td class="text-center"><?php echo e($v_ngredients->total); ?></td>
                                                    <td class="text-center">
                                                        <a role="button" class="btn btn-primary" href="">Accept</a>
                                                    </td>
                                                    <td class="text-center">
                                                        <a role="button" class="btn btn-primary" href="<?php echo e(route('purchases_modify',[$v_ngredients->id])); ?>">Modify</a>
                                                    </td>
                                                    <td class="text-center">
                                                        <a role="button" class="btn btn-danger" href="../purchases_single/<?php echo e($v_ngredients->id); ?>">Cancel</a>
                                                    </td>
                                                </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.box-body -->
                        </div>
                    </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>


    <script src="<?php echo $baseURL.'resources/assets/js/custom/serviceWorker.js'; ?>"></script>
    <script src="<?php echo $baseURL.'resources/assets/js/custom/restaurant/purchases.js'; ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/pages/restaurant/purchase/purchase/purchase_details.blade.php ENDPATH**/ ?>