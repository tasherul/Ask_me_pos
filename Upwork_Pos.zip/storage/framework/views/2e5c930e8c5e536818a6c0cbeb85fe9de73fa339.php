<div class="container">

    <nav class="navbar navbar-expand-lg navbar-light bg-dark bg-transparent">
        <button class="navbar-toggler mr-2" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="<?php echo e(route('index')); ?>">
            
            
            <h2 style="color: aliceblue;">                
                Ask me pos
            </h2>

        </a>
      
        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
            <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('index')); ?>">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('browseRestaurant')); ?>">Browse Restaurant</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="#">Contact</a>
                </li>
                <?php if(Auth::guard('customer')->check()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Profile
                        </a>
                        <div class="dropdown-menu bg-dark " aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('customer.profile')); ?>"><?php echo e(Auth::guard('customer')->user()->name); ?></a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo e(route('customer.logout')); ?>">Logout </a>
                        </div>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('customer.showSignUpForm')); ?>">Customer Login</a>
                    </li>
                <?php endif; ?>
          </ul>
        </div>
    </nav>
</div><?php /**PATH D:\wamp64\www\Upwork_Pos\ask_me_pos_2\resources\views/layouts/customer/header.blade.php ENDPATH**/ ?>