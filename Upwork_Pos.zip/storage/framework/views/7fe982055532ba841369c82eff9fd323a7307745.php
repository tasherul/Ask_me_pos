

<?php
$baseURL = getBaseURL()
?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Add Sub Category

                <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?></h3>
            </h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <!-- form start -->
                        <form method="post" action="<?php echo e(route('Catagory_Edit')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label>Name <span class="required_star">*</span></label>
                                            <input  type="text" name="name" class="form-control"
                                                   placeholder="Name" value="<?php echo e($edit_catagory->name); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Delay time (in minute) <span class="required_star">*</span></label>
                                            <input type="text" name="delay_time" class="form-control"
                                                   placeholder="" value="<?php echo e($edit_catagory->delay_time); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Description</label>
                                            <input type="text" name="description" class="form-control"
                                                   placeholder="Description" value="<?php echo e($edit_catagory->description); ?>">
                                        </div>
                                        
                                           <input type="hidden" name="hidden_id" value="<?php echo e($edit_catagory->id); ?>">     
                                    </div>
                                </div>
                            </div>
                            <!-- /.box-body -->

                            <div class="box-footer">
                                <button type="submit"  class="btn btn-primary">Update
                                </button>
                                <a href="../subcategory" role="button" class="btn btn-primary">Back
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/pages/restaurant/sale/subcategories/catagory_edit.blade.php ENDPATH**/ ?>