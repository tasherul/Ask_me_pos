

<?php
$baseURL = getBaseURL()
?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
        <section class="content-header">
            <h1>
              Add Payment Methods
            </h1>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-primary">
                        <form class="forms-sample">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Payment Methods Name</label>
                                <input type="text" class="form-control" placeholder="Payment Methods Name">
                            </div>
                            <div class="form-group">
                                <label>Describe</label>
                                <input type="text" class="form-control"  placeholder="Enter Describe">
                            </div>
                            <div class="form-group">
                                <label> Added By</label>
                                <input type="text" class="form-control" placeholder="Added By">
                            </div>
                            <div class="form-check">
                                <label class="form-check-label">
                                <input type="checkbox" class="form-check-input" checked>
                                Checked
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary mr-2">Submit</button>
                            <button class="btn btn-light">Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/pages/superAdmin/add-payment.blade.php ENDPATH**/ ?>