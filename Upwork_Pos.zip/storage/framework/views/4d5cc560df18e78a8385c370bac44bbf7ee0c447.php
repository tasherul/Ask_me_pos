<?php
$baseURL = getBaseURL();
?>

<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <ul class="sidebar-menu">
            <li class="header">Main Navigation</li>
        </ul>
        <div id="left_menu_to_scroll">
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu" data-widget="tree">
                <li>
                    <a href="<?php echo e(route('restaurant.home')); ?>">
                        <i data-feather="home"></i> <span>Home</span></a>
                </li>

                <li>
                    <a href="<?php echo e(route('restaurant.showSettings')); ?>">
                        <i data-feather="settings"></i> <span>Restaurant Settings</span>
                    </a>
                </li>

                <li class="treeview">
                    <a href="#">
                        <i data-feather="file-text"></i> <span>Purchase</span>
                        <span class="pull-right-container">
                                            <i class="fa fa-angle-left pull-right"></i>
                                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?php echo e(route('suppliers.index')); ?>"><i class="fa fa-angle-double-right"></i>Suppliers</a>
                        </li>
                        <li><a href="<?php echo e(route('ingredient-categories.index')); ?>"><i class="fa fa-angle-double-right"></i>Ingredient
                                Categories</a></li>
                        <li><a href="<?php echo e(route('ingredient-units.index')); ?>"><i class="fa fa-angle-double-right"></i>Ingredient
                                Units</a></li>
                        <li><a href="<?php echo e(route('ingredients.index')); ?>"><i class="fa fa-angle-double-right"></i>Ingredients</a>
                        </li>
                        <li><a href="<?php echo e(route('purchases.index')); ?>"><i class="fa fa-angle-double-right"></i>Purchase</a>
                        </li>
                    </ul>
                </li>

                <li class="treeview">
                    <a href="#">
                        <i data-feather="shopping-cart"></i> <span>Sale</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?php echo e(route('customer-groups.index')); ?>"><i class="fa fa-angle-double-right"></i>Customer Groups</a></li>
                        <li><a href="<?php echo e(route('customers.index')); ?>"><i class="fa fa-angle-double-right"></i>Customers</a></li>
                        <li><a href="<?php echo e(route('food-menu-shifts.index')); ?>"><i class="fa fa-angle-double-right"></i>Food Menu Shifts</a></li>
                        <li><a href="<?php echo e(route('food-menu-categories.index')); ?>"><i class="fa fa-angle-double-right"></i>Food Menu Categories</a></li>
                        <li><a href="<?php echo e(route('food-menu-modifiers.index')); ?>"><i class="fa fa-angle-double-right"></i>Food Menu Modifiers</a>
                        </li>
                        <li><a href="<?php echo e(route('kitchen-panels.index')); ?>"><i class="fa fa-angle-double-right"></i>Kitchen Panels</a>
                        </li>
                        <li><a href="<?php echo e(route('food-menu.index')); ?>"><i class="fa fa-angle-double-right"></i>Food Menus</a>
                        </li>
                        <li><a href="<?php echo e(route('floors.index')); ?>"><i class="fa fa-angle-double-right"></i>Floors</a></li>
                        <li><a href="<?php echo e(route('sales.index')); ?>"><i class="fa fa-angle-double-right"></i>Sales</a>
                        </li>
                        <li><a href="<?php echo e(route('pos.index')); ?>"><i class="fa fa-angle-double-right"></i>POS aka Add Sale</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(route('panels.all')); ?>">
                        <i data-feather="coffee"></i> <span>Kitchen Panels</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('waiter-panel.index')); ?>">
                        <i data-feather="coffee"></i> <span>Waiter Panel</span>
                    </a>
                </li>

                <li class="treeview">
                    <a href="#">
                        <i data-feather="dollar-sign"></i> <span>Expanse</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?php echo e(route('expense-items.index')); ?>"><i class="fa fa-angle-double-right"></i>Expense Items</a></li>
                        <li><a href="<?php echo e(route('expenses.index')); ?>"><i class="fa fa-angle-double-right"></i>Expenses</a></li>
                    </ul>
                </li>

                <li>
                    <a href="<?php echo e(route('wastes.index')); ?>">
                        <i data-feather="trash-2"></i> <span>Waste</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('attendances.index')); ?>">
                        <i data-feather="clock"></i> <span>Attendance</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('stock.index')); ?>">
                        <i data-feather="server"></i> <span>Stock</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('stock-adjustment.index')); ?>">
                        <i data-feather="sun"></i> <span>Stock Adjustment</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('gift-card.index')); ?>">
                        <i data-feather="credit-card"></i> <span>Gift Card</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('restaurant.reservation')); ?>">
                        <i data-feather="book"></i> <span>Reservation</span>
                    </a>
                </li>

                
            </ul>
        </div>
    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH D:\wamp64\www\Upwork_Pos\ask_me_pos_2\resources\views/layouts/restaurant/sidebar.blade.php ENDPATH**/ ?>