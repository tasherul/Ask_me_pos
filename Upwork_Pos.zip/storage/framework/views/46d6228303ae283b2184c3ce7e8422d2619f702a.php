

<?php
$baseURL = getBaseURL()
?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Add Expense 
            </h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <!-- form start -->
                        <form method="post" action="<?php echo e(route('expenses.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label>Date <span class="required_star">*</span></label>
                                            <input tabindex="1" type="date" name="date" class="form-control"
                                                   placeholder="Date" value="<?php echo e(old('date')); ?>">
                                        </div>

                                        <?php if($errors->has('date')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('date')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Amount <span class="required_star">*</span></label>
                                            <input tabindex="1" type="number" name="amount" class="form-control"
                                                   placeholder="Amount" value="<?php echo e(old('amount')); ?>">
                                        </div>

                                        <?php if($errors->has('amount')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('amount')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Category <span class="required_star">*</span></label>
                                            <select tabindex="3" class="form-control select2" name="category_id" style="width: 100%;">
                                                <option value="">Select</option>
                                                <?php $__currentLoopData = $expenseItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenseItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($expenseItem->id); ?>" <?php if($expenseItem->id == old('category_id')): ?> selected <?php endif; ?>><?php echo e($expenseItem->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        
                                        <?php if($errors->has('category_id')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('category_id')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label>Responsible Person <span class="required_star">*</span></label>
                                            <select tabindex="3" class="form-control select2" name="employee_id" style="width: 100%;">
                                                <option value="">Select</option>
                                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($employee->id); ?>" <?php if($employee->id == old('employee_id')): ?> selected <?php endif; ?>><?php echo e($employee->manager_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        
                                        <?php if($errors->has('employee_id')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('employee_id')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Note</label>
                                            <textarea tabindex="5" class="form-control" rows="4" name="note" placeholder="Note ..."><?php echo e(old('note')); ?></textarea>

                                        </div>

                                        <?php if($errors->has('note')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('note')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /.box-body -->

                            <div class="box-footer">
                                <button type="submit" name="submit" value="submit" class="btn btn-primary">Submit
                                </button>
                                <a href="<?php echo e(route('expenses.index')); ?>" role="button" class="btn btn-primary">Back
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        $(function () {
            //Initialize Select2 Elements
            $('.select2').select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/pages/restaurant/expense/expenses/create.blade.php ENDPATH**/ ?>