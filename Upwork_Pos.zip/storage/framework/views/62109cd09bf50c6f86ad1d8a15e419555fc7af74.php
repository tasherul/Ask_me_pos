

<?php
//$baseURL = getBaseURL()
?>

<?php $__env->startSection('content'); ?>
    <div class="login-box">
        <div class="content">

            <div class="bg_overlay"></div>
            <div class="logo-box">

            </div>


            <!-- /.login-logo -->
            <div class="login-box-body">
                <form method="post" action="<?php echo e(route('superAdmin.doLogin')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group has-feedback">
                        <input type="text" class="form-control" name="username_email_phone" value="<?php echo e(old('username_email_phone')); ?>" placeholder="Phone Number, Email Address Or Username">
                    </div>

                    <?php if($errors->has('username_email_phone')): ?>
                        <div class="alert alert-error" style="padding: 5px !important;">
                            <p>The Phone Number, Email Address Or Username field is required.</p>
                        </div>
                    <?php endif; ?>

                    <div class="form-group has-feedback pass">
                        <input type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control" placeholder="Password">
                    </div>

                    <?php if($errors->has('password')): ?>
                        <div class="alert alert-error" style="padding: 5px !important;">
                            <p><?php echo e($errors->first('password')); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <!-- /.col -->
                        <div class="col-xs-12">
                            <button type="submit" name="submit" value="submit" class="custom-btn">Login</button>
                        </div>
                        <!-- /.col -->
                    </div>
                </form>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/pages/superAdmin/login.blade.php ENDPATH**/ ?>