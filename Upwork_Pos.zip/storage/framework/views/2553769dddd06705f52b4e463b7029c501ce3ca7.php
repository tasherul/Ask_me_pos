

<?php
$baseURL = getBaseURL()
?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Edit Supplier
            </h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <!-- form start -->
                        <form method="post" action="<?php echo e(route('suppliers.update', [$supplier->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="PUT">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label>Name <span class="required_star">*</span></label>
                                            <input tabindex="1" type="text" name="name" class="form-control"
                                                   placeholder="Name" value="<?php echo e($supplier->name); ?>">
                                        </div>

                                        <?php if($errors->has('name')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('name')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Contact Person <span class="required_star">*</span></label>
                                            <input tabindex="1" type="text" name="contact_person" class="form-control"
                                                   placeholder="Contact Person" value="<?php echo e($supplier->contact_person); ?>">
                                        </div>

                                        <?php if($errors->has('contact_person')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('contact_person')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Phone <span class="required_star">*</span></label>
                                            <input tabindex="1" type="text" name="phone" class="form-control"
                                                   placeholder="Phone" value="<?php echo e($supplier->phone); ?>">
                                        </div>

                                        <?php if($errors->has('phone')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('phone')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Email</label>
                                            <input tabindex="1" type="text" name="email" class="form-control"
                                                   placeholder="Email" value="<?php echo e($supplier->email); ?>">
                                        </div>

                                        <?php if($errors->has('email')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('email')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Fax</label>
                                            <input tabindex="1" type="text" name="fax" class="form-control"
                                                   placeholder="Fax" value="<?php echo e($supplier->fax); ?>">
                                        </div>

                                        <?php if($errors->has('fax')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('fax')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Bank Name</label>
                                            <input tabindex="1" type="text" name="bank_name" class="form-control" value="<?php echo e($supplier->bank_name); ?>">
                                        </div>

                                        <?php if($errors->has('bank_name')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('bank_name')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Account Number</label>
                                            <input tabindex="1" type="text" name="account_number" class="form-control" value="<?php echo e($supplier->account_number); ?>">
                                        </div>

                                        <?php if($errors->has('account_number')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('account_number')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Routing Number</label>
                                            <input tabindex="1" type="text" name="routing_number" class="form-control"
                                                   value="<?php echo e($supplier->routing_number); ?>">
                                        </div>

                                        <?php if($errors->has('routing_number')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('routing_number')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Country</label>
                                            <select tabindex="1" class="form-control select2" name="country"
                                                    style="width: 100%;" id="country">
                                                <option value="">Select a Country</option>
                                                <?php if(count($countries) > 0): ?>
                                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($v->id); ?>"
                                                                <?php if($supplier->country_id === $v->id): ?> selected <?php endif; ?>><?php echo e($v->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('country')): ?>
                                                <div class="alert alert-error" style="padding: 5px !important;">
                                                    <p>
                                                    <p><?php echo e($errors->first('country')); ?></p></p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label>State</label>
                                            <select tabindex="1" class="form-control select2" name="state"
                                                    style="width: 100%;" id="state">
                                                <option value="">Select a State</option>
                                                <?php if($supplier->state_id): ?>
                                                    <option
                                                        value="<?php echo e($supplier->state_id); ?>" selected><?php echo getStateNameById($supplier->state_id); ?></option>
                                                <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('state')): ?>
                                                <div class="alert alert-error" style="padding: 5px !important;">
                                                    <p>
                                                    <p><?php echo e($errors->first('state')); ?></p></p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label>City</label>
                                            <select tabindex="1" class="form-control select2" name="city" id="city"
                                                    style="width: 100%;">
                                                <option value="">Select a City</option>
                                                <?php if($supplier->city_id): ?>
                                                    <option
                                                        value="<?php echo e($supplier->city_id); ?>" selected><?php echo getCityNameById($supplier->city_id); ?></option>
                                                <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('city')): ?>
                                                <div class="alert alert-error" style="padding: 5px !important;">
                                                    <p>
                                                    <p><?php echo e($errors->first('city')); ?></p></p>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group">
                                            <label>Zip</label>
                                            <input tabindex="1" type="text" name="zip" class="form-control"
                                                   placeholder="Zip" value="<?php echo e($supplier->zip); ?>">
                                        </div>

                                        <?php if($errors->has('zip')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('zip')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Address</label>
                                            <textarea name="address" class="form-control"
                                                      placeholder="Address"><?php echo e($supplier->address); ?></textarea>
                                        </div>

                                        <?php if($errors->has('address')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('address')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Description</label>
                                            <textarea name="description" class="form-control" rows="10"><?php echo e($supplier->description); ?></textarea>
                                        </div>

                                        <?php if($errors->has('description')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('description')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Category</label>
                                            <select tabindex="2" class="form-control select2" name="category[]" multiple="multiple"
                                                    style="width: 100%;">
                                                <?php if(count($categories) > 0): ?>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($v->id); ?>" <?php $__currentLoopData = $supplier->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if($s->id === $v->id): ?> selected <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($v->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>

                                        <?php if($errors->has('category')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('category')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        

                                        <div class="form-group">
                                            <label>Order Method</label><br>
                                            <label><input type="checkbox" name="order_method[]" value="Email" <?php if(!empty($supplier->order_method)): ?> <?php if(in_array("Email", json_decode($supplier->order_method))): ?> checked <?php endif; ?> <?php endif; ?>> Email</label><br>
                                            <label><input type="checkbox" name="order_method[]" value="SMS Message" <?php if(!empty($supplier->order_method)): ?> <?php if(in_array("SMS Message", json_decode($supplier->order_method))): ?> checked <?php endif; ?> <?php endif; ?>> SMS Message</label><br>
                                            <label><input type="checkbox" name="order_method[]" value="Fax" <?php if(!empty($supplier->order_method)): ?> <?php if(in_array("Fax", json_decode($supplier->order_method))): ?> checked <?php endif; ?> <?php endif; ?>> Fax</label><br>
                                        </div>

                                        <?php if($errors->has('order_method')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('order_method')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /.box-body -->

                            <div class="box-footer">
                                <button type="submit" name="submit" value="submit" class="btn btn-primary">submit
                                </button>
                                <a href="<?php echo e(route('suppliers.index')); ?>" role="button" class="btn btn-primary">Back
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
    <script src="<?php echo $baseURL.'resources/assets/js/custom/superAdmin/state.js'; ?>"></script>
    <script src="<?php echo $baseURL.'resources/assets/js/custom/serviceWorker.js'; ?>"></script>
    <script src="<?php echo $baseURL.'resources/assets/js/custom/restaurant/signUp.js'; ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/pages/restaurant/purchase/supplier/edit.blade.php ENDPATH**/ ?>