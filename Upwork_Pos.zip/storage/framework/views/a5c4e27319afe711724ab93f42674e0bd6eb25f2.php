<?php
$baseURL = getBaseURL()
?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Add Expense Category
            </h1>
            <?php if(session('success')): ?>
                            <div class="alert alert-success">
                            <p style="color: red;"> <?php echo e(session('success')); ?></p>
                            </div>
                            <?php endif; ?>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <!-- form start -->
                        
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <form method="Post" action="<?php echo e(route('expenses.expenses_add_category')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input  type="text" name="name" class="form-control"
                                                    placeholder="category" value="<?php echo e($edit_expenses->name); ?>" >
                                                </div>
                                                <div class="form-group">
                                                    <label>Description</label>
                                                    <input type="text" name="category_description" class="form-control"
                                                    placeholder="Description" value="<?php echo e($edit_expenses->description); ?>">
                                                </div>
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        <input type="checkbox" name="del_status" class="form-check-input" value="on" checked>
                                                            Live
                                                    </label>
                                                </div>

                                                <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary" id="addSupplier">
                                                    Update
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        $(function () {
            //Initialize Select2 Elements
            $('.select2').select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/pages/restaurant/expense/expenses/edit_expenses_category.blade.php ENDPATH**/ ?>