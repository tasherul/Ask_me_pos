

<?php
$baseURL = getBaseURL()
?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Edit Food Menu Category
            </h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <!-- form start -->
                        <form method="post" action="<?php echo e(route('food-menu-categories.update', [$category->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="PUT">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label>Name <span class="required_star">*</span></label>
                                            <input tabindex="1" type="text" name="name" class="form-control"
                                                   placeholder="Name" value="<?php echo e($category->name); ?>">
                                        </div>

                                        <?php if($errors->has('name')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('name')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Delay time (in minute) <span class="required_star">*</span></label>
                                            <input tabindex="1" type="text" name="delay_time" class="form-control"
                                                   placeholder="" value="<?php echo e($category->delay_time); ?>">
                                        </div>

                                        <?php if($errors->has('delay_time')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('delay_time')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Description</label>
                                            <input tabindex="1" type="text" name="description" class="form-control"
                                                   placeholder="Description" value="<?php echo e($category->description); ?>">
                                        </div>

                                        <?php if($errors->has('description')): ?>
                                            <div class="alert alert-error" style="padding: 5px !important;">
                                                <p><?php echo e($errors->first('description')); ?></p>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /.box-body -->

                            <div class="box-footer">
                                <button type="submit" name="submit" value="submit" class="btn btn-primary">submit
                                </button>
                                <a href="<?php echo e(route('food-menu-categories.index')); ?>" role="button" class="btn btn-primary">Back
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/pages/restaurant/sale/foodMenuCategory/edit.blade.php ENDPATH**/ ?>