

<?php
$baseURL = getBaseURL()
?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Settings Options
            </h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-primary">
                        <div class="box-body">
                            <a role="button" class="btn btn-primary" href="#">Google Map API setting
                            </a>&emsp;
                            <a role="button" class="btn btn-primary" href="#">Payment Gateway Setting
                            </a>&emsp;
                            <a role="button" class="btn btn-primary" href="<?php echo e(route('countries.index')); ?>">Countries
                            </a>&emsp;
                            <a role="button" class="btn btn-primary" href="<?php echo e(route('states.index')); ?>">States
                            </a>&emsp;
                            <a role="button" class="btn btn-primary" href="<?php echo e(route('cities.index')); ?>">Cities
                            </a>&emsp;
                            <a role="button" class="btn btn-primary" href="<?php echo e(route('cuisines.index')); ?>">Cuisines
                            </a>&emsp;
                            <a role="button" class="btn btn-primary" href="<?php echo e(route('privacyPolicies.show')); ?>">Privacy Policy
                            </a>&emsp;
                            <a role="button" class="btn btn-primary" href="<?php echo e(route('social-media.index')); ?>">Social Media
                            </a>&emsp;
                            <a role="button" class="btn btn-primary" href="<?php echo e(route('third-party-vendors.index')); ?>">3rd Parties Venders
                            </a>&emsp;
                            <br>
                            <a role="button" class="btn btn-primary" style="margin-top: 10px;" href="<?php echo e(route('charges.index')); ?>">Fee Charges
                            </a>&emsp;
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo $baseURL.'resources/assets/js/custom/superAdmin/privacyPolicies.js'; ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Upwork_Pos\resources\views/pages/superAdmin/settings/index.blade.php ENDPATH**/ ?>