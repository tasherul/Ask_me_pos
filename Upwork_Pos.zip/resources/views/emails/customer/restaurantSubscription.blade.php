<!DOCTYPE html>
<html lang="en">

<body>

<p>
    Thank you for choosing "{{ $restaurant['name'] }}". 
    You're subscribe to our this restaurant. Now you can receive dining offers and news from this restaurant by email.

    We do require masks to be worn when moving about the building. 
    We will be sanitizing all tables between seatings. 
    
</p>

<p>Thanks</p>

</body>

</html>
