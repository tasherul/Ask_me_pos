<!DOCTYPE html>
<html lang="en">

<body>

    <p>Dear {{ $receiver['name'] }},</p>
    <p>{{ $receiver['message'] }}</p>

    <p>Thanks</p>

</body>

</html>
