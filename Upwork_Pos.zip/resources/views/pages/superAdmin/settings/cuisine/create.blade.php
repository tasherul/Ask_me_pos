@extends('layouts.app')

<?php
$baseURL = getBaseURL()
?>

@section('content')
    <div class="content-wrapper">
    <section class="content-header">
        <h1>
            Add Cuisine
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <!-- form start -->
                    <form method="post" action="{{route('cuisines.store')}}">
                        @csrf
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">

                                    <div class="form-group">
                                        <label>Name <span class="required_star">*</span></label>
                                        <input tabindex="1" type="text" name="name" class="form-control" placeholder="Name" value="{{old('name')}}">
                                    </div>

                                    @if ($errors->has('name'))
                                        <div class="alert alert-error" style="padding: 5px !important;">
                                            <p>{{ $errors->first('name') }}</p>
                                        </div>
                                    @endif

                                </div>
                                <div class="col-md-6">
                                </div>

                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" name="submit" value="submit" class="btn btn-primary">submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    </div>
@endsection
