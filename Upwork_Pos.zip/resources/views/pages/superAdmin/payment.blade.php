@extends('layouts.app')

<?php
$baseURL = getBaseURL()
?>

@section('content')
<div class="content-wrapper">
        <section class="content-header">
            <h1>
                Payment Methods
            </h1>
            <a class="btn btn-info" style="float: right" href="addpayment">Add Payment Methods</a>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-primary">
                        
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@section('script')
    {{--    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/moment.min.js"></script>--}}
    {{--    <script src="{!! $baseURL.'resources/assets/js/custom/admin/dashboard.js'!!}"></script>--}}
@endsection
