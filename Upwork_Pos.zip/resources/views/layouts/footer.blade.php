<?php
$baseURL = getBaseURL();
?>

<footer class="main-footer">
    <div class="row">
        <div class="col-md-12" style="text-align: center;">
            <strong>&copy; Ask Me POS, 2020</strong>
            <div class="hidden-lg">

            </div>
        </div>
    </div>
</footer>
