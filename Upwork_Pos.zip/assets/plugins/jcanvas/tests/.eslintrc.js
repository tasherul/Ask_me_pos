// Configured for ESLint 3.19.0

'use strict';

module.exports = {

  env: {

    'qunit': true

  }

};
